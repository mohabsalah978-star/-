package com.thewolf.client;

import com.thewolf.TheWolfMod;
import com.thewolf.entity.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.util.Identifier;

public class TheWolfClient implements ClientModInitializer {
	public static final EntityModelLayer MODEL_LAYER =
		new EntityModelLayer(Identifier.of(TheWolfMod.MOD_ID, "the_wolf"), "main");

	@Override
	public void onInitializeClient() {
		EntityModelLayerRegistry.registerModelLayer(MODEL_LAYER, TheWolfModel::getTexturedModelData);
		EntityRendererRegistry.register(ModEntities.THE_WOLF, TheWolfRenderer::new);
	}
}
