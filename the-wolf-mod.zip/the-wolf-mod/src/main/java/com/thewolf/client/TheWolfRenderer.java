package com.thewolf.client;

import com.thewolf.TheWolfMod;
import com.thewolf.entity.TheWolfEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

public class TheWolfRenderer extends MobEntityRenderer<TheWolfEntity, LivingEntityRenderState, TheWolfModel> {
	private static final Identifier TEXTURE = Identifier.of(TheWolfMod.MOD_ID, "textures/entity/the_wolf.png");

	public TheWolfRenderer(EntityRendererFactory.Context ctx) {
		super(ctx, new TheWolfModel(ctx.getPart(TheWolfClient.MODEL_LAYER)), 0.6F);
	}

	@Override
	public LivingEntityRenderState createRenderState() {
		return new LivingEntityRenderState();
	}

	@Override
	public Identifier getTexture(LivingEntityRenderState state) {
		return TEXTURE;
	}

	// Always fully lit: the black body stays black, so only the white eyes and teeth glow in the dark.
	// (No @Override on purpose: if this method signature differs in your version, it is simply ignored.)
	protected int getBlockLight(TheWolfEntity entity, BlockPos pos) {
		return 15;
	}
}
