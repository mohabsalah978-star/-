package com.thewolf.client;

import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;

/** Tall, thin, long-armed wolf. Feet are at y = 24 in model space, everything is placed with absolute coordinates. */
public class TheWolfModel extends EntityModel<LivingEntityRenderState> {
	public TheWolfModel(ModelPart root) {
		super(root);
	}

	public static TexturedModelData getTexturedModelData() {
		ModelData data = new ModelData();
		ModelPartData root = data.getRoot();

		root.addChild("head", ModelPartBuilder.create().uv(0, 0).cuboid(-3.5F, -22.0F, -4.0F, 7.0F, 8.0F, 7.0F), ModelTransform.NONE);
		root.addChild("snout", ModelPartBuilder.create().uv(28, 0).cuboid(-2.0F, -18.5F, -9.0F, 4.0F, 4.0F, 5.0F), ModelTransform.NONE);
		root.addChild("ear_r", ModelPartBuilder.create().uv(46, 0).cuboid(-3.5F, -27.0F, -1.0F, 2.0F, 5.0F, 2.0F), ModelTransform.NONE);
		root.addChild("ear_l", ModelPartBuilder.create().uv(54, 0).cuboid(1.5F, -27.0F, -1.0F, 2.0F, 5.0F, 2.0F), ModelTransform.NONE);
		root.addChild("body", ModelPartBuilder.create().uv(0, 16).cuboid(-4.0F, -12.0F, -2.0F, 8.0F, 20.0F, 4.0F), ModelTransform.NONE);
		root.addChild("arm_r", ModelPartBuilder.create().uv(24, 16).cuboid(-6.0F, -10.0F, -1.5F, 2.0F, 26.0F, 3.0F), ModelTransform.NONE);
		root.addChild("arm_l", ModelPartBuilder.create().uv(34, 16).cuboid(4.0F, -10.0F, -1.5F, 2.0F, 26.0F, 3.0F), ModelTransform.NONE);
		root.addChild("leg_r", ModelPartBuilder.create().uv(44, 16).cuboid(-3.5F, 8.0F, -1.5F, 3.0F, 16.0F, 3.0F), ModelTransform.NONE);
		root.addChild("leg_l", ModelPartBuilder.create().uv(0, 41).cuboid(0.5F, 8.0F, -1.5F, 3.0F, 16.0F, 3.0F), ModelTransform.NONE);

		return TexturedModelData.of(data, 64, 64);
	}
}
