package com.thewolf;

import com.mojang.brigadier.Command;
import com.thewolf.entity.ModEntities;
import com.thewolf.entity.WolfSpawner;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

public class TheWolfMod implements ModInitializer {
	public static final String MOD_ID = "thewolf";

	@Override
	public void onInitialize() {
		ModEntities.register();

		// Natural spawning: every 10 seconds, small chance per player (only in the dark).
		ServerTickEvents.END_WORLD_TICK.register(WolfSpawner::tick);

		// Test command: /thewolf  -> spawns the wolf near you.
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
			dispatcher.register(CommandManager.literal("thewolf").executes(ctx -> {
				ServerCommandSource source = ctx.getSource();
				ServerPlayerEntity player = source.getPlayerOrThrow();
				boolean ok = WolfSpawner.spawnNear(source.getWorld(), player, 18, 24, false);
				source.sendFeedback(() -> Text.literal(ok ? "He is watching..." : "Could not find a spot, try again."), false);
				return ok ? Command.SINGLE_SUCCESS : 0;
			}))
		);
	}
}
