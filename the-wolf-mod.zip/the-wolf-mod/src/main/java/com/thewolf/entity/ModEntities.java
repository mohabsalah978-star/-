package com.thewolf.entity;

import com.thewolf.TheWolfMod;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;

public class ModEntities {
	public static final RegistryKey<EntityType<?>> THE_WOLF_KEY =
		RegistryKey.of(RegistryKeys.ENTITY_TYPE, Identifier.of(TheWolfMod.MOD_ID, "the_wolf"));

	public static final EntityType<TheWolfEntity> THE_WOLF = Registry.register(
		Registries.ENTITY_TYPE,
		THE_WOLF_KEY,
		EntityType.Builder.create(TheWolfEntity::new, SpawnGroup.MONSTER)
			.dimensions(0.7f, 3.0f)
			.build(THE_WOLF_KEY)
	);

	public static void register() {
		FabricDefaultAttributeRegistry.register(THE_WOLF, TheWolfEntity.createAttributes());
	}
}
