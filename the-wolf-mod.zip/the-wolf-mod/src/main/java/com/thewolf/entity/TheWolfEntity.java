package com.thewolf.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * The Wolf: freezes while you look at it, creeps toward you when you look away.
 * If you get close while looking at it, or stare too long, it vanishes (with a scare).
 */
public class TheWolfEntity extends PathAwareEntity {
	private int watchedTicks = 0;
	private int attackCooldown = 0;

	public TheWolfEntity(EntityType<? extends PathAwareEntity> type, World world) {
		super(type, world);
	}

	public static DefaultAttributeContainer.Builder createAttributes() {
		return MobEntity.createMobAttributes()
			.add(EntityAttributes.MAX_HEALTH, 60.0)
			.add(EntityAttributes.MOVEMENT_SPEED, 0.32)
			.add(EntityAttributes.ATTACK_DAMAGE, 6.0)
			.add(EntityAttributes.FOLLOW_RANGE, 64.0);
	}

	@Override
	protected void initGoals() {
		this.goalSelector.add(0, new SwimGoal(this));
	}

	@Override
	public void tick() {
		super.tick();
		if (!(this.getEntityWorld() instanceof ServerWorld world)) {
			return;
		}

		PlayerEntity target = world.getClosestPlayer(this.getX(), this.getY(), this.getZ(), 64.0, true);
		if (target == null) {
			if (this.age > 600) {
				this.discard();
			}
			return;
		}

		if (this.attackCooldown > 0) {
			this.attackCooldown--;
		}

		double dist = Math.sqrt(this.squaredDistanceTo(target));

		// Is the player looking at the wolf?
		Vec3d look = target.getRotationVec(1.0F);
		Vec3d toWolf = this.getEyePos().subtract(target.getEyePos()).normalize();
		boolean watched = look.dotProduct(toWolf) > 0.55 && target.canSee(this);

		if (watched) {
			// Freeze in place and stare back.
			this.getNavigation().stop();
			this.setVelocity(0.0, this.getVelocity().y, 0.0);
			this.getLookControl().lookAt(target, 60.0F, 60.0F);
			this.watchedTicks++;

			if (this.age % 25 == 0 && dist < 32.0) {
				play(world, target, SoundEvents.ENTITY_WARDEN_HEARTBEAT, 1.0F, 0.7F);
			}

			if (dist < 6.0 || this.watchedTicks > 500) {
				vanish(world, target);
			}
		} else {
			this.watchedTicks = Math.max(0, this.watchedTicks - 2);

			if (this.age % 5 == 0) {
				this.getNavigation().startMovingTo(target, 1.5);
			}

			if (dist < 2.3 && this.attackCooldown <= 0) {
				this.attackCooldown = 40;
				target.damage(world, world.getDamageSources().mobAttack(this), 6.0F);
				play(world, target, SoundEvents.ENTITY_WARDEN_ATTACK_IMPACT, 1.0F, 0.6F);
			}

			if (this.random.nextInt(160) == 0) {
				play(world, target, SoundEvents.ENTITY_WARDEN_NEARBY_CLOSER, 0.8F, 0.8F);
			}
		}
	}

	private void vanish(ServerWorld world, PlayerEntity target) {
		play(world, target, SoundEvents.ENTITY_ENDERMAN_SCREAM, 1.0F, 0.5F);
		target.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 140, 0, false, false, true));
		world.spawnParticles(ParticleTypes.LARGE_SMOKE, this.getX(), this.getY() + 1.5, this.getZ(), 40, 0.3, 1.0, 0.3, 0.02);
		this.discard();
	}

	private static void play(ServerWorld world, PlayerEntity at, SoundEvent sound, float volume, float pitch) {
		world.playSound(null, at.getX(), at.getY(), at.getZ(), sound, SoundCategory.HOSTILE, volume, pitch);
	}
}
