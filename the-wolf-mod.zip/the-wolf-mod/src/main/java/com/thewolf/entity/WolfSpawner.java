package com.thewolf.entity;

import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;

public class WolfSpawner {
	/** Called every tick for every world. */
	public static void tick(ServerWorld world) {
		if (world.getTime() % 200 != 0) {
			return;
		}
		for (ServerPlayerEntity player : world.getPlayers()) {
			if (player.isSpectator() || player.isCreative()) {
				continue;
			}
			if (world.getRandom().nextInt(8) != 0) {
				continue;
			}
			boolean alreadyHere = !world.getEntitiesByClass(
				TheWolfEntity.class, player.getBoundingBox().expand(128.0), e -> true).isEmpty();
			if (alreadyHere) {
				continue;
			}
			spawnNear(world, player, 28, 40, true);
		}
	}

	public static boolean spawnNear(ServerWorld world, PlayerEntity player, int minDist, int maxDist, boolean requireDark) {
		for (int attempt = 0; attempt < 12; attempt++) {
			double angle = world.getRandom().nextDouble() * Math.PI * 2.0;
			double dist = minDist + world.getRandom().nextDouble() * (maxDist - minDist);
			int x = (int) Math.floor(player.getX() + Math.cos(angle) * dist);
			int z = (int) Math.floor(player.getZ() + Math.sin(angle) * dist);
			int y = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
			BlockPos pos = new BlockPos(x, y, z);

			if (Math.abs(y - player.getY()) > 12) {
				continue;
			}
			if (requireDark && world.getLightLevel(pos) > 7) {
				continue;
			}
			if (world.getBlockState(pos.down()).isAir() || !world.getFluidState(pos).isEmpty()) {
				continue;
			}

			TheWolfEntity wolf = ModEntities.THE_WOLF.create(world, SpawnReason.EVENT);
			if (wolf == null) {
				return false;
			}
			wolf.setPosition(x + 0.5, y, z + 0.5);
			wolf.setYaw(world.getRandom().nextFloat() * 360.0F);
			world.spawnEntity(wolf);
			return true;
		}
		return false;
	}
}
