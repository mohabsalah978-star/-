# The Wolf (Fabric 1.21.11)

Run in dev:    ./gradlew runClient
Build the jar: ./gradlew build   ->  build/libs/the-wolf-1.0.0.jar
In game:       /thewolf   (spawns the wolf near you for testing)
